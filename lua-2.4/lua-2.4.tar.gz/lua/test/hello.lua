-- the first program in every language

print("hello world, from Lua!")
