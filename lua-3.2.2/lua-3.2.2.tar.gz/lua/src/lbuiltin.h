/*
** $Id: lbuiltin.h,v 1.1 1997/09/16 19:25:59 roberto Exp $
** Built-in functions
** See Copyright Notice in lua.h
*/

#ifndef lbuiltin_h
#define lbuiltin_h


void luaB_predefine (void);


#endif
